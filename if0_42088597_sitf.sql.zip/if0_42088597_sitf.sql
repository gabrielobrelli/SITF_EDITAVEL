-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: sql200.infinityfree.com
-- Tempo de geração: 19/08/2026 às 07:06
-- Versão do servidor: 11.4.12-MariaDB
-- Versão do PHP: 7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `if0_42088597_sitf`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `avaliacoes`
--

CREATE TABLE `avaliacoes` (
  `id` varchar(36) NOT NULL,
  `vaga_id` varchar(36) NOT NULL,
  `avaliador_id` varchar(36) NOT NULL,
  `avaliado_id` varchar(36) NOT NULL,
  `tipo` enum('empregador_avalia_freelancer','freelancer_avalia_empregador') NOT NULL,
  `nota` tinyint(4) NOT NULL
) ;

--
-- Despejando dados para a tabela `avaliacoes`
--

INSERT INTO `avaliacoes` (`id`, `vaga_id`, `avaliador_id`, `avaliado_id`, `tipo`, `nota`, `comentario`, `criado_em`) VALUES
('6a1c9977b2cb46.12961103', '6a1c97dbbdca22.92136013', '6a1c974bc6c6a1.69652961', '6a1c513fa7ec35.75125709', 'empregador_avalia_freelancer', 4, 'bom, mas preguiçoso', '2026-05-31 20:26:31'),
('6a1c99c2490d40.42537793', '6a1c97dbbdca22.92136013', '6a1c513fa7ec35.75125709', '6a1c974bc6c6a1.69652961', 'freelancer_avalia_empregador', 3, 'trampo chato', '2026-05-31 20:27:46'),
('6a1eb9797fe379.37387031', '6a1eb890189274.54490369', '6a1b5362bee405.12923328', '6a1eb7cb190562.47074329', 'freelancer_avalia_empregador', 5, 'legal', '2026-06-02 11:07:37'),
('6a1eb9b9243872.07245608', '6a1eb890189274.54490369', '6a1eb7cb190562.47074329', '6a1b5362bee405.12923328', 'empregador_avalia_freelancer', 5, 'legal', '2026-06-02 11:08:41'),
('6a1ecb95ba86d8.27597296', '6a1c97dbbdca22.92136013', '6a1c974bc6c6a1.69652961', '6a1ecb040e27f3.97371622', 'empregador_avalia_freelancer', 5, 'gostoso demais', '2026-06-02 12:24:53');

-- --------------------------------------------------------

--
-- Estrutura para tabela `candidaturas`
--

CREATE TABLE `candidaturas` (
  `id` varchar(36) NOT NULL,
  `vaga_id` varchar(36) NOT NULL,
  `freelancer_id` varchar(36) NOT NULL,
  `status` enum('pendente','aprovado','reprovado') DEFAULT 'pendente',
  `visto` tinyint(1) DEFAULT 0,
  `criado_em` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Despejando dados para a tabela `candidaturas`
--

INSERT INTO `candidaturas` (`id`, `vaga_id`, `freelancer_id`, `status`, `visto`, `criado_em`) VALUES
('6a1c98505c70b3.66510658', '6a1c97dbbdca22.92136013', '6a1c513fa7ec35.75125709', 'aprovado', 1, '2026-05-31 20:21:36'),
('6a1e180037cc93.99684232', '6a1e17b7ed15b9.53184299', '6a1c513fa7ec35.75125709', 'pendente', 0, '2026-06-01 23:38:40'),
('6a1eb923360ee6.38977154', '6a1eb890189274.54490369', '6a1b5362bee405.12923328', 'aprovado', 1, '2026-06-02 11:06:11'),
('6a1ecb13745b85.92444374', '6a1c97dbbdca22.92136013', '6a1ecb040e27f3.97371622', 'aprovado', 1, '2026-06-02 12:22:43');

-- --------------------------------------------------------

--
-- Estrutura para tabela `historico_servicos`
--

CREATE TABLE `historico_servicos` (
  `id` varchar(36) NOT NULL,
  `freelancer_id` varchar(36) NOT NULL,
  `empregador_id` varchar(36) NOT NULL,
  `titulo` varchar(150) NOT NULL,
  `descricao` text DEFAULT NULL,
  `valor` decimal(10,2) DEFAULT 0.00,
  `data_inicio` date DEFAULT NULL,
  `data_fim` date DEFAULT NULL,
  `status` enum('em_andamento','concluido','cancelado') DEFAULT 'concluido',
  `criado_em` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `mensagens`
--

CREATE TABLE `mensagens` (
  `id` varchar(36) NOT NULL,
  `chat_key` varchar(100) NOT NULL,
  `sender_id` varchar(36) NOT NULL,
  `texto` text NOT NULL,
  `lido` tinyint(1) DEFAULT 0,
  `criado_em` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Despejando dados para a tabela `mensagens`
--

INSERT INTO `mensagens` (`id`, `chat_key`, `sender_id`, `texto`, `lido`, `criado_em`) VALUES
('6a1c988827f879.24627159', '6a1c513fa7ec35.75125709_6a1c974bc6c6a1.69652961', '6a1c974bc6c6a1.69652961', 'ola joao', 1, '2026-05-31 20:22:32'),
('6a1e182318c0f2.15793244', '6a1c513fa7ec35.75125709_6a1e1778251f94.22083675', '6a1c513fa7ec35.75125709', 'oii', 1, '2026-06-01 23:39:15'),
('6a1e3a6eb6cf62.94893630', '6a1c513fa7ec35.75125709_6a1c974bc6c6a1.69652961', '6a1c513fa7ec35.75125709', 'oi', 1, '2026-06-02 02:05:34'),
('6a1eb9529a4477.62869350', '6a1b5362bee405.12923328_6a1eb7cb190562.47074329', '6a1eb7cb190562.47074329', 'oiiiiiiiiiiiiiiiiiiiiiiiiiiii', 1, '2026-06-02 11:06:58');

-- --------------------------------------------------------

--
-- Estrutura para tabela `usuarios`
--

CREATE TABLE `usuarios` (
  `id` varchar(36) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `senha` varchar(255) NOT NULL,
  `tipo` enum('freelancer','empregador') NOT NULL,
  `cidade` varchar(100) DEFAULT NULL,
  `estado` varchar(2) DEFAULT NULL,
  `bio` text DEFAULT NULL,
  `skills` text DEFAULT NULL,
  `rate` decimal(10,2) DEFAULT 0.00,
  `rate_type` varchar(20) DEFAULT 'hora',
  `portfolio` varchar(255) DEFAULT NULL,
  `rating` decimal(3,2) DEFAULT 0.00,
  `reviews` int(11) DEFAULT 0,
  `projetos` int(11) DEFAULT 0,
  `online` tinyint(1) DEFAULT 0,
  `site` varchar(255) DEFAULT NULL,
  `criado_em` timestamp NULL DEFAULT current_timestamp(),
  `telefone` varchar(20) DEFAULT NULL,
  `email_contato` varchar(100) DEFAULT NULL,
  `foto` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Despejando dados para a tabela `usuarios`
--

INSERT INTO `usuarios` (`id`, `nome`, `email`, `senha`, `tipo`, `cidade`, `estado`, `bio`, `skills`, `rate`, `rate_type`, `portfolio`, `rating`, `reviews`, `projetos`, `online`, `site`, `criado_em`, `telefone`, `email_contato`, `foto`) VALUES
('6a1b5362bee405.12923328', 'Gabriel Obrelli', 'gabrielhenriquedesouzaobrelli@gmail.com', '$2y$12$cnBhL8f.5WY2K3CGp3jQcuXls9Cy9lSHKyi26vwuXw.ucR5P/iw02', 'freelancer', '', '', '', '', '0.00', 'hora', '', '5.00', 1, 0, 1, NULL, '2026-05-30 21:15:15', NULL, NULL, NULL),
('6a1b5ddd7c6b67.78319040', 'frederico munhoz', 'vectra2010@outlook.com', '$2y$12$sxh0f86PxyyX5LQh4/.Ad.esFwIc.jQ5zOOml4BmOXXPrWZLR.mLO', 'freelancer', '', '', '', '', '0.00', 'hora', '', '0.00', 0, 0, 1, NULL, '2026-05-30 21:59:57', NULL, NULL, NULL),
('6a1c513fa7ec35.75125709', 'Joao Alberto', 'joaoalberto@gmail.com', '$2y$12$GK/JDUHb8ZEL2GoyYchS4uWDnVyoSBbZBuffieewdPW50mRZjpSDa', 'freelancer', 'Ourinhos', '', '', '', '0.00', 'hora', '', '4.00', 1, 0, 1, '', '2026-05-31 15:18:23', NULL, NULL, NULL),
('6a1c974bc6c6a1.69652961', 'Gabriel Souza', 'gabrielsouza@gmail.com', '$2y$12$/D3hqbbQdF5GQ9Mn5VROI.puf0wN8.wLvgSo.Wf3rNEO6WP/jzvdy', 'empregador', 'Ourinhos', '', '', '', '0.00', 'hora', '', '3.00', 1, 0, 1, '', '2026-05-31 20:17:16', '', '', NULL),
('6a1e1778251f94.22083675', 'murilo goncalves', 'murilo@gmail.com', '$2y$12$py76Ey2CBkGNK5HAPBtAZ.6b7m8Tgm3NyyirdV0.rGajn2VR.HLIO', 'empregador', '', '', '', '', '0.00', 'hora', '', '0.00', 0, 0, 1, NULL, '2026-06-01 23:36:24', NULL, NULL, NULL),
('6a1eb73ce8cd25.81846422', 'Isabela Carnaval', 'isabela@gmail.com', '$2y$12$b9mrz4HKjrqh9a7ws3YBYeMIbmkLGTish4rO0IikV.nivIVGQzwBu', 'freelancer', 'Ourinhos', 'SP', 'Prazer', 'Sei ler', '0.00', 'hora', '', '0.00', 0, 0, 1, '', '2026-06-02 10:58:05', NULL, NULL, NULL),
('6a1eb7cb190562.47074329', 'Bia Matias', 'biamatias@gmail.com', '$2y$12$S68Br7FIRoTtFSTWlQUsIOfl1XU5jL.Mm2W0ZVSsk5aSRsOLejX7u', 'empregador', 'Ourinhos', '', 'restaurante que precisa de gente pra ler', '', '0.00', 'hora', '', '5.00', 1, 0, 1, 'biaamat_/instagram', '2026-06-02 11:00:27', '14999252940', 'biaempresa@gmail.com', NULL),
('6a1ecb040e27f3.97371622', 'roberto atila', 'mecicareca10@gmail.com', '$2y$12$AquCHBWlPisJ3FjPUjwj5eiGIVweLE9/Put85iSuIUEAE92rULX5O', 'freelancer', '', '', '', '', '0.00', 'hora', '', '5.00', 1, 0, 1, NULL, '2026-06-02 12:22:28', NULL, NULL, NULL),
('6a1ecc45bff372.18552229', 'matheus chaves', 'matheuschaves@gmail.com', '$2y$12$m1MIJ6ATIrz.0uZoma2ZwOna3TC82ajK9F0tqo.Y3KG4QxDIYBDX.', 'empregador', '', '', '', '', '0.00', 'hora', '', '0.00', 0, 0, 1, NULL, '2026-06-02 12:27:50', NULL, NULL, NULL),
('e1', 'TechStart', 'tech@start.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'empregador', 'São Paulo', 'SP', 'Startup de tecnologia em saúde digital.', NULL, '0.00', 'hora', NULL, '4.70', 15, 0, 1, 'techstart.com.br', '2026-05-30 20:59:29', NULL, NULL, NULL),
('e2', 'AppCorp', 'app@corp.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'empregador', 'Rio de Janeiro', 'RJ', 'Empresa de desenvolvimento de aplicativos móveis.', NULL, '0.00', 'hora', NULL, '4.50', 22, 0, 1, 'appcorp.com.br', '2026-05-30 20:59:29', NULL, NULL, NULL),
('f1', 'Ana Souza', 'ana@email.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'freelancer', 'São Paulo', 'SP', 'Desenvolvedora Full Stack com 5 anos de experiência em React e Node.js.', 'React,Node.js,AWS,TypeScript', '130.00', 'hora', 'github.com/anasouza', '4.90', 38, 52, 1, NULL, '2026-05-30 20:59:29', NULL, NULL, NULL),
('f2', 'Carlos Lima', 'carlos@email.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'freelancer', 'Rio de Janeiro', 'RJ', 'Designer UI/UX especializado em produtos digitais.', 'Figma,Motion,Branding,Design System', '120.00', 'hora', 'behance.net/carloslima', '4.80', 24, 34, 1, NULL, '2026-05-30 20:59:29', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Estrutura para tabela `vagas`
--

CREATE TABLE `vagas` (
  `id` varchar(36) NOT NULL,
  `titulo` varchar(150) NOT NULL,
  `empresa` varchar(100) NOT NULL,
  `empregador_id` varchar(36) NOT NULL,
  `categoria` varchar(50) NOT NULL,
  `preco` decimal(10,2) NOT NULL,
  `tipo_preco` varchar(20) DEFAULT 'hora',
  `modalidade` enum('Remoto','Presencial','Híbrido') NOT NULL,
  `cidade` varchar(100) DEFAULT NULL,
  `estado` varchar(2) DEFAULT NULL,
  `descricao` text NOT NULL,
  `tags` text DEFAULT NULL,
  `status` enum('aberta','encerrada') DEFAULT 'aberta',
  `destaque` tinyint(1) DEFAULT 0,
  `criado_em` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Despejando dados para a tabela `vagas`
--

INSERT INTO `vagas` (`id`, `titulo`, `empresa`, `empregador_id`, `categoria`, `preco`, `tipo_preco`, `modalidade`, `cidade`, `estado`, `descricao`, `tags`, `status`, `destaque`, `criado_em`) VALUES
('6a1c97dbbdca22.92136013', 'Garçon', 'Gabriel Souza', '6a1c974bc6c6a1.69652961', 'Design', '100.00', 'dia', 'Presencial', 'Ourinhos', 'SP', 'Procuramos garçons para suprir a nececidade da pizzaria Verona', '', 'encerrada', 0, '2026-05-31 20:19:39'),
('6a1e17b7ed15b9.53184299', 'hvufyv', 'murilo goncalves', '6a1e1778251f94.22083675', 'Design', '1000.00', 'hora', 'Remoto', 'chvas', '', 'atrapalhante', '', 'aberta', 1, '2026-06-01 23:37:27'),
('6a1eb890189274.54490369', 'Leitor', 'Bia Matias', '6a1eb7cb190562.47074329', 'Redação', '132.00', 'dia', 'Presencial', 'Ourinhos', 'SP', 'Saber ler e nao ser analfabeto', 'sabe,ler', 'aberta', 0, '2026-06-02 11:03:44'),
('6a1eba14736df1.30696000', 'aaaaaaaaaaa', 'Bia Matias', '6a1eb7cb190562.47074329', 'Manobrista', '111.00', 'hora', 'Presencial', 'aaaaaaaaaaa', '', 'ssssssssssssssss', 'qqqqqqqqqqqqq', 'aberta', 1, '2026-06-02 11:10:12');

--
-- Índices de tabelas apagadas
--

--
-- Índices de tabela `candidaturas`
--
ALTER TABLE `candidaturas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `vaga_id` (`vaga_id`),
  ADD KEY `freelancer_id` (`freelancer_id`);

--
-- Índices de tabela `historico_servicos`
--
ALTER TABLE `historico_servicos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `freelancer_id` (`freelancer_id`),
  ADD KEY `empregador_id` (`empregador_id`);

--
-- Índices de tabela `mensagens`
--
ALTER TABLE `mensagens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sender_id` (`sender_id`);

--
-- Índices de tabela `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Índices de tabela `vagas`
--
ALTER TABLE `vagas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `empregador_id` (`empregador_id`);

--
-- Restrições para dumps de tabelas
--

--
-- Restrições para tabelas `candidaturas`
--
ALTER TABLE `candidaturas`
  ADD CONSTRAINT `candidaturas_ibfk_1` FOREIGN KEY (`vaga_id`) REFERENCES `vagas` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `candidaturas_ibfk_2` FOREIGN KEY (`freelancer_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE;

--
-- Restrições para tabelas `historico_servicos`
--
ALTER TABLE `historico_servicos`
  ADD CONSTRAINT `historico_servicos_ibfk_1` FOREIGN KEY (`freelancer_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `historico_servicos_ibfk_2` FOREIGN KEY (`empregador_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE;

--
-- Restrições para tabelas `mensagens`
--
ALTER TABLE `mensagens`
  ADD CONSTRAINT `mensagens_ibfk_1` FOREIGN KEY (`sender_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE;

--
-- Restrições para tabelas `vagas`
--
ALTER TABLE `vagas`
  ADD CONSTRAINT `vagas_ibfk_1` FOREIGN KEY (`empregador_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
